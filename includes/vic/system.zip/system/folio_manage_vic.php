<?php  
set_include_path('includes/vic/enquiry/document_handler');

include('main.php');
